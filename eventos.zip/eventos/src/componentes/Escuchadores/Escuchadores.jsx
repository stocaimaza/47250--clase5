import { useEffect } from "react";

const Escuchadores = () => {

    window.addEventListener("resize", ()=> {
        console.log("Cambiaste la pantalla!!!!")
    });

    window.addEventListener("click", ()=> {
        console.log("realizaste un nuevo click!");
    })

    //Lo correcto seria hacer algo así: 

    useEffect( ()=> {
        function click()  {
            console.log("Click");

            return () => {
                window.removeEventListener("click", click);
            }
        }
    }, [])

  return (
    <div>Escuchadores</div>
  )
}

export default Escuchadores