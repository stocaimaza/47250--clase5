import { useState } from "react";
import './Eventos.css';

const Eventos = () => {
    const [input, setInput] = useState("");

    const manejadorClick = () => {
        console.log("Click");
    }

    const manejadorInput = (event) => {
        //Voy a trabajar con el objeto "event".
        setInput(event.target.value);
        //La propiedad target es la referencia al bojeto del DOM que dispara el evento. 
        //Value es el texto que ingreso el usuario. 
        console.log(input);

    }

  return (
    <div>
        {/* onClick  */}
        <button onClick={manejadorClick}> Haceme Click </button>

        {/* onMouseMove, onMouseEnter, onMouseLeave */}
        <div className="caja"
            onMouseMove={()=> console.log("Pasaste el micky mouse")}
            onMouseEnter={()=> console.log("Ingresaste!")}
            onMouseLeave={()=> console.log("Saliste!")}
        ></div>

        {/* onChange, onKeyDown, onKeyUp */}

        <form>
            <h2>{input} </h2>
            <label htmlFor="campo"> Ingrese Texto </label>
            <input type="text" id="campo" 
                onChange={manejadorInput}
                onKeyDown={()=> console.log("Presionaste una tecla!")}
                onKeyUp={()=> console.log("Soltaste una tecla!")}
            />
        </form>
        {/* 
            htmlFor = es igual al for que usamos en HTML
            change = se dispara cuando el usuario cambia el valor del input
            keyDown = cuando presionamos una tecla. 
            keyUp = cuando soltamos una tecla. 
        
        */}



    </div>
  )
}

export default Eventos