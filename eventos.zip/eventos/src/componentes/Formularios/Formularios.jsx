import { useState } from "react";

const Formularios = () => {
    const [nombre, setNombre] = useState("");
    const [apellido, setApellido] = useState("");
    const [email, setEmail] = useState("");

    //Creamos un manejador para el evento submit: 
    const manejadorFormulario = (e) => {
        e.preventDefault();
        const nuevoCliente = {nombre, apellido, email};
        console.log(nuevoCliente);

        //Limpiamos los input: 
        setNombre("");
        setApellido("");
        setEmail("");
    }

  return (
    <form onSubmit={manejadorFormulario}>
        <h2>Datos de Contacto</h2>
        
        <label htmlFor="">Nombre </label>
        <input type="text" onChange={(e)=>setNombre(e.target.value)} value={nombre} />
        <br /><br />

        <label htmlFor="">Apellido</label>
        <input type="text" onChange={(e)=>setApellido(e.target.value)} value={apellido}/>
        <br /><br />

        <label htmlFor="">Correo Electrónico</label>
        <input type="email" onChange={(e)=> setEmail(e.target.value)} value={email} />
        <br /><br />

        <button type="submit">Enviar datos</button>

    </form>
  )
}

export default Formularios