import React from 'react'
//import Eventos from './componentes/Eventos/Eventos';
//import Formularios from './componentes/Formularios/Formularios';
//import Escuchadores from './componentes/Escuchadores/Escuchadores'
import Automatico from './componentes/Automatico/Automatico'

const App = () => {
  return (
    <div>
        <Automatico/>

    </div>
  )
}

export default App

/*
 EN JS Vainilla usamos eventos con: 

 1) addEventListener
 2) Propiedades de los nodos. 

 const tituloPrincipal = document.getElementById("titulo");
 tituloPrincipal.onMouseMove = (acá metiamos la función con el comportamiento buscado)

 3) Era como atributo en las etiquetas HTML.



*/